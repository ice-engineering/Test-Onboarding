Deploy to Azure

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FShivniel%2FAzure%2Fmaster%2FAzureSentinelviaARMLighthouse%2FLighthouseVersion%2Fligthousesentineldeploy.json/createUIDefinitionUri/https%3A%2F%2Fraw.githubusercontent.com%2FShivniel%2FAzure%2Fmaster%2FAzureSentinelviaARMLighthouse%2FLighthouseVersion%2FcreateUiDefinition.json)
